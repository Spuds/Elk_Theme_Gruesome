<?php
// Version: 1.1; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.png';
$txt['theme_description'] = 'A dark theme with chocolate accents. Gruesome by Antechinus';